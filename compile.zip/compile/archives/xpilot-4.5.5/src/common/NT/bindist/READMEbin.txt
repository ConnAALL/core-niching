This is the README for XPilot.exe Release 13 .
XPilot.exe is based on 4.5.5 .

Copyright � 1991-2002 by Bj�rn Stabell, Ken Ronny Schouten, Bert Gijsbers & Dick Balaska.

The documentation for XPilot is far from complete.

Be sure to read doc/Changelog for information about the differences
between this release and previous releases.

--------------------------------------
SOURCES OF INFORMATION ON THE INTERNET

XPilot Page on WWW: http://www.xpilot.org/

XPilot.exe info on WWW: http://www.buckosoft.com/xpilot/

--------------------------------------
REPORTING BUGS

If you're completely stuck, found a bug, or want to say Hi! e-mail us at:

        xpilot@xpilot.org

Remember to include the version of XPilot, your platform, the symptoms
and, if you have one, a fix when reporting bugs.
