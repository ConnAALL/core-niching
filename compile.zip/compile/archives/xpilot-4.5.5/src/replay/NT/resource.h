//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by XPreplay.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_SLIDERBAR                   103
#define IDR_MAINFRAME                   128
#define IDR_XPREPLTYPE                  129
#define IDD_PROPERTIES                  130
#define IDC_NICK                        1000
#define IDC_USERHOST                    1001
#define IDC_SERVERADDRESS               1003
#define IDC_RECDATE                     1004
#define IDC_FPS                         1005
#define IDC_STATIC_URL1                 1008
#define IDC_STATIC_URL2                 1009
#define IDC_STATIC_URL3                 1010
#define IDC_SLIDER1                     1011
#define IDT_STOP                        32771
#define IDT_PLAY                        32772
#define IDT_REVERSE                     32773
#define IDT_FORWARD                     32774
#define IDT_REWIND                      32775
#define IDT_TOSTART                     32776
#define IDT_TOEND                       32777
#define IDT_PAUSE                       32778
#define IDT_STARTFRAME                  32779
#define IDT_ENDFRAME                    32780
#define ID_FILE_PROPERTIES              32781
#define ID_OPTIONS_TRUSTHEADERFORSIZE   32782
#define ID_OPTIONS_USEDEFAULTCOLORS     32783
#define ID_OPTIONS_TRUSTHEADER          32784
#define ID_SLOWPLAY                     32785
#define ID_SLOWBACK                     32786
#define IDT_SLOWBACK                    32787
#define IDT_SLOWPLAY                    32788
#define ID_VIEW_SLIDERBAR               32789
#define ID_BUTTON32792                  32792
#define ID_INDICATOR_FRAMECOUNTER       59142

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32803
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
