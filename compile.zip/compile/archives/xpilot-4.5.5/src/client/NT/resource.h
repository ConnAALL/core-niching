//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by XPilot.rc
//
#define IDD_ABOUTBOX                    100
#define IDB_SPLASH                      102
#define IDP_SOCKETS_INIT_FAILED         104
#define IDR_MAINFRAME                   128
#define IDR_XPILOTTYPE                  129
#define IDD_MOTD                        131
#define IDB_AUTOPILOT                   136
#define IDB_AFTERBURNER                 137
#define IDB_CLOAK                       138
#define IDD_TALKWINDOW                  139
#define IDD_EXPIRE_SOON                 141
#define IDD_EXPIRED                     142
#define IDI_XPILOTS                     143
#define IDD_SYSINFO                     143
#define IDC_EDIT1                       1001
#define IDC_CREDITS                     1005
#define IDC_VERSION                     1006
#define ID_CONFIGURE                    32771
#define ID_ABOUT                        32773
#define ID_CONFIGURE_SYSINFO            32774
#define ID_COLORS                       32775
#define ID_CONFIGURE_FONTS              32776
#define ID_CONFIGURE_GAME               32777

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        148
#define _APS_NEXT_COMMAND_VALUE         32778
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
