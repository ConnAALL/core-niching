This is the README file for XPilot 4.5.5.

Copyright � 1991-2002 by Bj�rn Stabell, Ken Ronny Schouten, Bert Gijsbers & Dick Balaska.

Please see the LICENSE file for further details.  You may not
distribute this project without all the documentation,
source code, and the LICENSE file.



Installation instructions are in the INSTALL.txt file.

NT and Win95 users should examine the src/common/NT/bindist subdirectory
and read the README.txt which is in there.

The documentation for XPilot is far from complete.  The map format is
only explained in doc/README.MAPS and doc/README.MAPS2, not in the server
manual page, xpilots(6).  The client manual page, xpilot(6), is more or
less up to date.

For further reading, see the manuals in the doc/man directory.



CONTRIBUTED SOFTWARE

Check out the contrib directory subdirectory for some extra nifty programs.
Especially TkXpInterface is a very convenient program for starting the
xpilots and xpilot programs.

Also try the mapeditor which is included in this XPilot distribution.  
It is a nifty graphical editor with which you can design a new XPilot world.


$Id: README.txt.msub,v 5.2 2010/02/21 15:55:17 bertg Exp $
