#! /bin/bash
# Evan Gray - 17 Dec 2017
# Install dependencies
#~ sudo apt-get install xutils-dev gcc make libx11-dev libxext-dev
# Download and compile XPilot
mkdir xpilot-ai
#wget https://gitlab.com/xpilot-ai/xpilot-ai/raw/master/archives/xpilot-4.5.5.tar.bz2
#tar xjf xpilot-4.5.5.tar.bz2
#rm xpilot-4.5.5.tar.bz2
cd xpilot-4.5.5
echo;echo "Building and Installing XPilot. This may take a few minutes."
find . -type f -exec sed -i 's/getline/xpgetline/g' {} +
xmkmf -a
make CC='gcc -fPIC' --silent
# Relocate files
cp -r share ../xpilot-ai/
#~ mv src/server/xpilots ../xpilot-ai/
mv src/client/xpilot ../xpilot-ai/
mv src/mapedit/xp-mapedit ../xpilot-ai/
mv src/replay/xp-replay ../xpilot-ai/
# Download and compile our alternate server
cd src/server/
wget https://gitlab.com/xpilot-ai/xpilot-ai/raw/master/source/globalAI.h
wget https://gitlab.com/xpilot-ai/xpilot-ai/raw/master/source/cmdlineAI.c
wget https://gitlab.com/xpilot-ai/xpilot-ai/raw/master/source/playerAI.c
gcc -fPIC -O -I../common/ -I../lib/ -Dlinux -D__amd64__ -D_POSIX_C_SOURCE=199309L -D_XOPEN_SOURCE -D_SVID_SOURCE -D_LARGEFILE_SOURCE -D_FILE_OFFSET_BITS=64 -DFUNCPROTO=15 -DNARROWPROTO -c -o playerAI.o playerAI.c
gcc -fPIC -O -I../common/ -I../lib/ -Dlinux -D__amd64__ -D_POSIX_C_SOURCE=199309L -D_XOPEN_SOURCE -D_SVID_SOURCE -D_LARGEFILE_SOURCE -D_FILE_OFFSET_BITS=64 -DFUNCPROTO=15 -DNARROWPROTO -c -o cmdlineAI.o cmdlineAI.c
gcc -fPIC -o xpilots -O alliance.o asteroid.o cannon.o cell.o cmdlineAI.o collision.o command.o contact.o event.o fileparser.o frame.o id.o item.o laser.o map.o metaserver.o netserver.o object.o objpos.o option.o parser.o play.o playerAI.o robot.o robotdef.o rules.o saudio.o sched.o score.o server.o ship.o shot.o showtime.o stratbot.o tuner.o update.o walls.o wildmap.o ../common/libxpcommon.a -lm
cd ../..
mv src/server/xpilots ../xpilot-ai
# Download and compile AI code
cd src/client/
#wget https://gitlab.com/xpilot-ai/xpilot-ai/raw/master/source/clientAI.c
#wget https://gitlab.com/xpilot-ai/xpilot-ai/raw/master/source/clientAI.h
#wget https://gitlab.com/xpilot-ai/xpilot-ai/raw/master/source/defaultAI.c
#wget https://gitlab.com/xpilot-ai/xpilot-ai/raw/master/source/paintdataAI.c
#wget https://gitlab.com/xpilot-ai/xpilot-ai/raw/master/source/painthudAI.c
#wget https://gitlab.com/xpilot-ai/xpilot-ai/raw/master/source/xpilotAI.c
gcc -fPIC -O -I../common/ -I../../lib/ -Dlinux -D__i386__ -D_POSIX_C_SOURCE=199309L -D_POSIX_SOURCE -D_XOPEN_SOURCE -D_BSD_SOURCE -D_SVID_SOURCE -D_LARGEFILE_SOURCE -D_FILE_OFFSET_BITS=64 -DFUNCPROTO=15 -DNARROWPROTO -DWINDOWSCALING -c -o clientAI.o clientAI.c
gcc -fPIC -O -I../common/ -I../../lib/ -Dlinux -D__i386__ -D_POSIX_C_SOURCE=199309L -D_POSIX_SOURCE -D_XOPEN_SOURCE -D_BSD_SOURCE -D_SVID_SOURCE -D_LARGEFILE_SOURCE -D_FILE_OFFSET_BITS=64 -DFUNCPROTO=15 -DNARROWPROTO -DWINDOWSCALING -c -o defaultAI.o defaultAI.c
gcc -fPIC -O -I../common/ -I../../lib/ -Dlinux -D__i386__ -D_POSIX_C_SOURCE=199309L -D_POSIX_SOURCE -D_XOPEN_SOURCE -D_BSD_SOURCE -D_SVID_SOURCE -D_LARGEFILE_SOURCE -D_FILE_OFFSET_BITS=64 -DFUNCPROTO=15 -DNARROWPROTO -DWINDOWSCALING -c -o paintdataAI.o paintdataAI.c
gcc -fPIC -O -I../common/ -I../../lib/ -Dlinux -D__i386__ -D_POSIX_C_SOURCE=199309L -D_POSIX_SOURCE -D_XOPEN_SOURCE -D_BSD_SOURCE -D_SVID_SOURCE -D_LARGEFILE_SOURCE -D_FILE_OFFSET_BITS=64 -DFUNCPROTO=15 -DNARROWPROTO -DWINDOWSCALING -c -o painthudAI.o painthudAI.c
gcc -fPIC -O -I../common/ -I../../lib/ -Dlinux -D__i386__ -D_POSIX_C_SOURCE=199309L -D_POSIX_SOURCE -D_XOPEN_SOURCE -D_BSD_SOURCE -D_SVID_SOURCE -D_LARGEFILE_SOURCE -D_FILE_OFFSET_BITS=64 -DFUNCPROTO=15 -DNARROWPROTO -DWINDOWSCALING -c -o xpilotAI.o xpilotAI.c
echo;echo "Cleaning up!"
cd ../../..
#rm -r xpilot-4.5.5
# Install Xpilot-AI maps
cd xpilot-ai
echo;echo "Installing maps!"
wget https://gitlab.com/xpilot-ai/xpilot-ai/raw/master/archives/maps.tar.gz
tar xfz maps.tar.gz
rm maps.tar.gz

